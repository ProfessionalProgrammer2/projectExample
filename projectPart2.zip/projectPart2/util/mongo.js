const MongoClient = require("mongodb").MongoClient;
const MongoURL = "mongodb://localhost:27017";

function getConnection(callback)
  {
        return MongoClient.connect(MongoURL, callback);

        // return MongoClient.connect(MongoURL, function(err, db) {
        //   if (err) throw err;
        //   var dbo = db.db("imdb");
        //   dbo.collection("movie").find({}).toArray(function(err, result) {
        //     if (err) throw err;
        //     console.log(result);
        //     db.close();
        //   });
        // });
  }


module.exports = {
    getConnection
}