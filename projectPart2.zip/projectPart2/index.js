const express = require("express");
const router = express.Router();
const { getConnection } = require("./util/mongo")
const WeatherModel = require("./model/weather");


router.get("/", (req, res) => {
    WeatherModel.find((err, docs)=>{
        console.log(err, docs);
        res.send(docs);
    })
});


router.post("/", (req, res) => {

    const username = req.body.username;
    const email= req.body.email;
    const password = req.body.password;
    const weather = new WeatherModel({
        username : username,
        email : email,
        password : password
        
    })

    weather.save((err)=>{
        res.send({})
    })

    // or 
    WeatherModel.insertMany([{

    }]).then

});

router.get("/login", (req, res) => {
    getConnection((err, client) => {
        if (err) throw err;
        const db = client.db("WeatherInfo");
        if (req.body.username == "Admin" && req.body.password == "Admin")
        {
            var collection = db.collection("Admin");
        }
        else
        {
            var collection = db.collection("User");
        }
        
        collection.find({ achievements: { $exists: true } }).toArray((err, docs) => {
            if (err) throw err;
            res.send(docs);
        })
    })
});

router.get("/achievements/:username", (req, res) => {
    getConnection((err, client) => {
        if (err) throw err;
        const db = client.db("cerification");
        const collection = db.collection("users");
        collection.findOne({ username: req.params.username }, (err, docs) => {
            if (err) throw err;
            res.send(docs);
        })
    })
});

router.get("/search", (req, res)=>{

    getConnection((err, client) => {
        if (err) throw err;
        const db = client.db("cerification");
        const collection = db.collection("users");
       // require('../views/search').get(req, res);
        collection.findOne({ username: req.body.username }, (err, docs) => {
            if (err) throw err;
            res.send(docs);
        })
    })

//     if(req.body.name !== "")
//     {
//         const User = new MovieModel({
//             name : req.body.name
//         })
//         User.save();
//         // res.send("user has been added...");
//       //  res.redirect("/search")
//     }
// else
//     {
//         res.send("user input is invalid.");
//     }
    // UserModel.find().then((response)=>{
    //     console.log(response);

    //     Router.get("/dashboard", (req, res)=>{
    //         UserModel.find().then((response)=>{
    //             console.log(response);
        
              
        
    //             res.render("dashboard", { posts : response });
    //         })
    //     });
        

    //     res.render("dashboard", { posts : response });
    // })
});


module.exports = router;