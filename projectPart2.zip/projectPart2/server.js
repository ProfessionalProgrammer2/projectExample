const express = require("express");
const bodyParser = require("body-parser");
const app = express();
///new
const path = require('path');

const mongoose = require("mongoose");
const db = mongoose.connect("mongodb://localhost:27017", { useNewUrlParser: true })

const home = require("./index")
const name = require("./routes/name");
const rating = require("./routes/rating");

app.use(bodyParser.json({ type : "application/json" }))
app.use(bodyParser.text({ type : "text/html" }))

//new
app.use(bodyParser.urlencoded({ extended: false }));
//app.use(express.static(path.resolve(-__dirname, 'public')))


var mongodb = require('mongodb');

app.use("/", home);
app.use("/signUp", name);
app.use("/rating", rating);

///new
app.post('/post-feedback', function (req, res) {
    db.then(function(db) {
        delete req.body._id; // for safety reasons
        db.collection('feedbacks').insertOne(req.body);
    });    
    res.send('Data received:\n' + JSON.stringify(req.body));
});

app.listen(3000, ()=>{
    console.log("Server Started...  3000")
});