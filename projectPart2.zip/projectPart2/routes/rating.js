const express = require("express");
const router = express.Router();
const { getConnection } = require("../util/mongo")

// /rating/rating/:abc

router.get("/:abc", (req, res) => {
    console.log("req.params", req.params)
    const rating = parseInt(req.params.abc);
    getConnection((err, client) => {
        if (err) throw err;
        const db = client.db("cerification");
        const collection = db.collection("users");
        collection.find({ rating: { $gte: rating } })
            .toArray((err, docs) => {
                if (err) throw err;
                res.send(docs);
            })
    })
});

module.exports = router;