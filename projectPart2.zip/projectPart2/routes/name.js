const express = require("express");
const router = express.Router();
const { getConnection } = require("../util/mongo")

router.get("/:username", (req, res) => {
    getConnection((err, client) => {
        if (err) throw err;
        const db = client.db("cerification");
        const collection = db.collection("users");
        collection.findOne({ username: req.params.username }, (err, docs) => {
            if (err) throw err;
            res.send(docs);
        })
    })
});


router.put("/:username", (req, res) => {
    getConnection((err, client) => {
        if (err) throw err;
        const db = client.db("cerification");
        const collection = db.collection("users");
        collection.update({
            username: req.params.username,
        }, {
            $set: {
                username : req.body.username,
                email: req.body.email,
                password: req.body.password
            }
        }, (err, docs) => {
            if(err) throw err;
            res.send(docs);
        })
    })
});

router.delete("/:username", (req, res) => {
    getConnection((err, client) => {
        if (err) throw err;
        const db = client.db("certification");
        const collection = db.collection("users");
        collection.remove({
            username: req.params.username,
        }, (err, docs) => {
            res.send(docs);
        })
    })
});

module.exports = router;